const ext = chrome;
const radios = document.querySelectorAll('input[name="mode"]');
const urlWrap = document.getElementById("url-wrap");
const urlInput = document.getElementById("custom-url");
const saveBtn = document.getElementById("save-btn");
const statusEl = document.getElementById("status");
const permBanner = document.getElementById("perm-banner");
const grantPermBtn = document.getElementById("grant-perm-btn");

function normalizeUrl(raw) {
  const trimmed = (raw || "").trim();
  if (!trimmed) return "";
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return "https://" + trimmed;
}

function syncVisibility() {
  const selected = document.querySelector('input[name="mode"]:checked').value;
  urlWrap.classList.toggle("hidden", selected !== "custom");
}

async function checkPerms() {
  if (!ext.permissions || !ext.permissions.contains) return;
  try {
    const has = await ext.permissions.contains({ origins: ["<all_urls>"] });
    const selected = document.querySelector('input[name="mode"]:checked').value;
    permBanner.classList.toggle("hidden", has || selected !== "custom");
  } catch {}
}

radios.forEach(r => r.addEventListener("change", () => {
  syncVisibility();
  checkPerms();
}));

ext.storage.local.get(["mode", "customUrl"]).then((data) => {
  const mode = data.mode || "default";
  radios.forEach(r => { r.checked = (r.value === mode); });
  if (data.customUrl) urlInput.value = data.customUrl;
  syncVisibility();
  checkPerms();
});

grantPermBtn.addEventListener("click", async () => {
  if (ext.permissions && ext.permissions.request) {
    try {
      await ext.permissions.request({ origins: ["<all_urls>"] });
      checkPerms();
    } catch {}
  }
});

saveBtn.addEventListener("click", async () => {
  const selected = document.querySelector('input[name="mode"]:checked').value;
  const customUrl = normalizeUrl(urlInput.value);
  if (selected === "custom" && !customUrl) {
    urlInput.focus();
    statusEl.style.color = "#dc2626";
    statusEl.textContent = "Please enter a valid URL.";
    return;
  }
  if (selected === "custom" && ext.permissions && ext.permissions.request) {
    try {
      await ext.permissions.request({ origins: ["<all_urls>"] });
    } catch {}
  }
  await ext.storage.local.set({ mode: selected, customUrl });
  statusEl.style.color = "#16a34a";
  statusEl.textContent = "Saved!";
  checkPerms();
  setTimeout(() => { statusEl.textContent = ""; }, 1800);
});
