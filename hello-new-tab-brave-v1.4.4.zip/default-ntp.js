const ENGINES = {
  google: {
    name: "Google",
    url: "https://www.google.com/search?q=",
    icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#5B5B66" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><circle cx="11" cy="11" r="7"></circle><line x1="20" y1="20" x2="16.2" y2="16.2"></line></svg>`
  },
  brave: {
    name: "Brave Search",
    url: "https://search.brave.com/search?q=",
    icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="#FB542B" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L4 5.5v6.2c0 5.1 3.4 9.8 8 11.3 4.6-1.5 8-6.2 8-11.3V5.5L12 2zm0 4.2l3.5 2.1-1.2 3.7H9.7L8.5 8.3 12 6.2zm0 11.6c-2.2-.9-3.8-3.1-4.1-5.6h8.2c-.3 2.5-1.9 4.7-4.1 5.6z"/></svg>`
  },
  ddg: {
    name: "DuckDuckGo",
    url: "https://duckduckgo.com/?q=",
    icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10" fill="#DE5833"/><circle cx="10.5" cy="9.5" r="1.4" fill="#FFF"/><circle cx="14.5" cy="9.5" r="1.4" fill="#FFF"/><path d="M9 14c1.5 1.5 4.5 1.5 6 0" stroke="#FFD13B" stroke-width="2" stroke-linecap="round"/></svg>`
  }
};

function setIconSvg(container, svgMarkup) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(svgMarkup, "image/svg+xml");
  const svgEl = doc.documentElement;
  container.replaceChildren(document.importNode(svgEl, true));
}

const engineIcon = document.getElementById("engine-icon");
const engineSelect = document.getElementById("engine-select");
const searchInput = document.getElementById("search-input");
const searchForm = document.getElementById("search-form");

function applyEngine(key) {
  const eng = ENGINES[key] || ENGINES.google;
  setIconSvg(engineIcon, eng.icon);
  searchInput.placeholder = `Search with ${eng.name} or enter address`;
  engineSelect.value = key in ENGINES ? key : "google";
  localStorage.setItem("ntp_engine", engineSelect.value);
}

applyEngine(localStorage.getItem("ntp_engine") || "google");

engineSelect.addEventListener("change", () => applyEngine(engineSelect.value));
engineIcon.addEventListener("click", () => {
  const keys = Object.keys(ENGINES);
  const next = keys[(keys.indexOf(engineSelect.value) + 1) % keys.length];
  applyEngine(next);
});

searchForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const q = searchInput.value.trim();
  if (!q) return;
  const isUrl = /^(https?:\/\/)?([\w-]+\.)+[a-z]{2,}(\/.*)?$/i.test(q) && !q.includes(" ");
  const target = isUrl
    ? (q.startsWith("http://") || q.startsWith("https://") ? q : `https://${q}`)
    : ENGINES[engineSelect.value].url + encodeURIComponent(q);
  if (window.top) {
    window.top.location.href = target;
  } else {
    window.location.href = target;
  }
});

// Background customization
const bgFile = document.getElementById("bg-file");
const resetBgBtn = document.getElementById("reset-bg-btn");

function applySavedBg() {
  const savedBg = localStorage.getItem("ntp_bg");
  if (savedBg) {
    document.body.style.backgroundImage = `url("${savedBg}")`;
    document.body.classList.add("has-custom-bg");
  } else {
    document.body.style.backgroundImage = "";
    document.body.classList.remove("has-custom-bg");
  }
}
applySavedBg();

bgFile.addEventListener("change", () => {
  const file = bgFile.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    localStorage.setItem("ntp_bg", reader.result);
    applySavedBg();
  };
  reader.readAsDataURL(file);
});

resetBgBtn.addEventListener("click", () => {
  localStorage.removeItem("ntp_bg");
  applySavedBg();
});

// Panel toggle
const pencilBtn = document.getElementById("pencil-btn");
const panel = document.getElementById("customize-panel");
pencilBtn.addEventListener("click", () => panel.classList.toggle("hidden"));

// Weather with multi-provider IP fallback + caching
const weatherCard = document.getElementById("weather-card");
const toggleWeather = document.getElementById("toggle-weather");
const changeCityBtn = document.getElementById("change-city-btn");
const wCity = document.getElementById("w-city");
const wIcon = document.getElementById("w-icon");
const wNow = document.getElementById("w-now");
const wRange = document.getElementById("w-range");

function codeToEmoji(code) {
  if (code === 0) return "☀️";
  if (code <= 3) return "⛅";
  if (code <= 48) return "🌫️";
  if (code <= 67) return "🌧️";
  if (code <= 77) return "❄️";
  if (code <= 82) return "🌦️";
  return "⛈️";
}

async function fetchWeatherByCoords(lat, lon, label) {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&temperature_unit=fahrenheit&timezone=auto`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Weather fetch failed");
  const data = await res.json();
  wCity.textContent = label;
  wIcon.textContent = codeToEmoji(data.current.weather_code);
  wNow.textContent = `${Math.round(data.current.temperature_2m)}°F`;
  wRange.textContent = `↑${Math.round(data.daily.temperature_2m_max[0])}°  ↓${Math.round(data.daily.temperature_2m_min[0])}°`;
}

async function detectLocationViaIP() {
  const cached = localStorage.getItem("ntp_ip_geo_cache");
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Date.now() - parsed.ts < 3600000 && parsed.lat && parsed.lon) {
        return parsed;
      }
    } catch {}
  }

  const providers = [
    async () => {
      const r = await fetch("https://ipwho.is/");
      const d = await r.json();
      if (d && d.success !== false && d.latitude && d.longitude) {
        return { lat: d.latitude, lon: d.longitude, city: d.city || d.region || "Local" };
      }
      throw new Error("ipwho failed");
    },
    async () => {
      const r = await fetch("https://get.geojs.io/v1/ip/geo.json");
      const d = await r.json();
      if (d && d.latitude && d.longitude) {
        return { lat: parseFloat(d.latitude), lon: parseFloat(d.longitude), city: d.city || d.region || "Local" };
      }
      throw new Error("geojs failed");
    },
    async () => {
      const r = await fetch("https://freeipapi.com/api/json");
      const d = await r.json();
      if (d && d.latitude && d.longitude) {
        return { lat: d.latitude, lon: d.longitude, city: d.cityName || d.regionName || "Local" };
      }
      throw new Error("freeipapi failed");
    },
    async () => {
      const r = await fetch("https://ipapi.co/json/");
      const d = await r.json();
      if (d && d.latitude && d.longitude) {
        return { lat: d.latitude, lon: d.longitude, city: d.city || d.region || "Local" };
      }
      throw new Error("ipapi failed");
    }
  ];

  for (const fn of providers) {
    try {
      const loc = await fn();
      localStorage.setItem("ntp_ip_geo_cache", JSON.stringify({ ...loc, ts: Date.now() }));
      return loc;
    } catch {}
  }
  return null;
}

async function loadWeather() {
  if (localStorage.getItem("ntp_weather_off") === "1") {
    weatherCard.classList.add("hidden");
    toggleWeather.checked = false;
    return;
  }
  weatherCard.classList.remove("hidden");
  toggleWeather.checked = true;

  const customCity = localStorage.getItem("ntp_city");
  try {
    if (customCity) {
      const gRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(customCity)}&count=1`);
      const gData = await gRes.json();
      if (gData.results && gData.results[0]) {
        const r = gData.results[0];
        await fetchWeatherByCoords(r.latitude, r.longitude, r.name);
        return;
      }
    }
    const ipLoc = await detectLocationViaIP();
    if (ipLoc) {
      await fetchWeatherByCoords(ipLoc.lat, ipLoc.lon, ipLoc.city);
      return;
    }
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          await fetchWeatherByCoords(pos.coords.latitude, pos.coords.longitude, "Local Weather");
        },
        () => { wCity.textContent = "Set City"; },
        { timeout: 5000 }
      );
    } else {
      wCity.textContent = "Set City";
    }
  } catch {
    wCity.textContent = "Weather Unavailable";
  }
}

function promptCity() {
  const current = localStorage.getItem("ntp_city") || "";
  const next = prompt("Enter city name (leave blank for automatic detection):", current);
  if (next === null) return;
  if (next.trim()) {
    localStorage.setItem("ntp_city", next.trim());
  } else {
    localStorage.removeItem("ntp_city");
    localStorage.removeItem("ntp_ip_geo_cache");
  }
  loadWeather();
}

weatherCard.addEventListener("click", promptCity);
changeCityBtn.addEventListener("click", promptCity);
toggleWeather.addEventListener("change", () => {
  if (toggleWeather.checked) {
    localStorage.removeItem("ntp_weather_off");
  } else {
    localStorage.setItem("ntp_weather_off", "1");
  }
  loadWeather();
});

loadWeather();
