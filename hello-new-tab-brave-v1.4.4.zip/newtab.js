const ext = chrome;
const frame = document.getElementById("ntp-frame");
const overlay = document.getElementById("setup-overlay");
const chooseDefault = document.getElementById("choose-default");
const chooseCustom = document.getElementById("choose-custom");
const setupUrlInput = document.getElementById("setup-url-input");

function normalizeUrl(raw) {
  const trimmed = (raw || "").trim();
  if (!trimmed) return "";
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return "https://" + trimmed;
}

function renderState(data) {
  if (!data || !data.mode) {
    overlay.classList.remove("hidden");
    frame.src = "default-ntp.html";
    return;
  }
  overlay.classList.add("hidden");
  if (data.mode === "custom" && data.customUrl) {
    frame.src = data.customUrl;
  } else {
    frame.src = "default-ntp.html";
  }
}

ext.storage.local.get(["mode", "customUrl"]).then(renderState);

ext.storage.onChanged.addListener((changes, area) => {
  if (area === "local") {
    ext.storage.local.get(["mode", "customUrl"]).then(renderState);
  }
});

chooseDefault.addEventListener("click", async () => {
  await ext.storage.local.set({ mode: "default" });
  overlay.classList.add("hidden");
  frame.src = "default-ntp.html";
});

chooseCustom.addEventListener("click", async () => {
  const url = normalizeUrl(setupUrlInput.value);
  if (!url) {
    setupUrlInput.focus();
    return;
  }
  if (ext.permissions && ext.permissions.request) {
    try {
      await ext.permissions.request({ origins: ["<all_urls>"] });
    } catch {}
  }
  await ext.storage.local.set({ mode: "custom", customUrl: url });
  overlay.classList.add("hidden");
  frame.src = url;
});
