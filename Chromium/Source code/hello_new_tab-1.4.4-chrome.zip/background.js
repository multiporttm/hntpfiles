// Cleans up the per-tab header-stripping rules that newtab.js creates.
// A rule exists only while a tab is showing the Hello New Tab page in
// Custom URL mode; as soon as the tab leaves that page or closes, its rule goes.

function isNewTabPage(url) {
  return (
    url.startsWith("chrome://newtab") ||
    url.startsWith("chrome-search://") ||
    url.startsWith(chrome.runtime.getURL(""))
  );
}

async function removeRuleForTab(tabId) {
  try {
    const rules = await chrome.declarativeNetRequest.getSessionRules();
    if (rules.some((r) => r.id === tabId)) {
      await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [tabId] });
    }
  } catch (e) {}
}

chrome.tabs.onRemoved.addListener((tabId) => removeRuleForTab(tabId));

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url && !isNewTabPage(changeInfo.url)) removeRuleForTab(tabId);
});

chrome.tabs.onReplaced.addListener((_added, removedTabId) => removeRuleForTab(removedTabId));

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg && msg.type === "ntp-leaving" && sender.tab) removeRuleForTab(sender.tab.id);
});
