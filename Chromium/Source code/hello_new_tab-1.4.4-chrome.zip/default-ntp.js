const SVG_NS = "http://www.w3.org/2000/svg";

const SEARCH_SVG = `<svg xmlns="${SVG_NS}" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#5B5B66" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>`;

const ENGINES = {
  google: {
    name: "Google",
    url: "https://www.google.com/search?q=",
    icon: SEARCH_SVG
  },
  brave: {
    name: "Brave Search",
    url: "https://search.brave.com/search?q=",
    icon: `<svg xmlns="${SVG_NS}" width="20" height="20" viewBox="0 0 24 24"><path fill="#FB542B" d="M12 2L4 5.5v6.2c0 5.1 3.4 9.8 8 11.3 4.6-1.5 8-6.2 8-11.3V5.5L12 2z"/><path fill="#FFF" d="M12 6.2l3.8 2.1-.9 3.2 1.4 2.1-4.3 4.2-4.3-4.2 1.4-2.1-.9-3.2L12 6.2z"/></svg>`
  },
  ddg: {
    name: "DuckDuckGo",
    url: "https://duckduckgo.com/?q=",
    icon: `<svg xmlns="${SVG_NS}" width="20" height="20" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#DE5833"/><path fill="#FFF" d="M10.5 7.5c1.8 0 3 1.2 3 2.8 0 1.1-.6 1.9-1.4 2.3l2.6 1.1c.4.2.5.7.2 1-.5.5-1.3.7-2.2.5l-2.2-.5v2.8H9V8.5c0-.6.6-1 1.5-1z"/></svg>`
  }
};
const DEFAULT_ENGINE = "google";

const engineIcon = document.getElementById("engine-icon");
const searchInput = document.getElementById("search-input");
const searchForm = document.getElementById("search-form");
const engineSelect = document.getElementById("engine-select");
const pencilBtn = document.getElementById("pencil-btn");
const panel = document.getElementById("customize-panel");
const panelMsg = document.getElementById("panel-msg");
const toggleWeather = document.getElementById("toggle-weather");
const weatherCard = document.getElementById("weather-card");
const changeCityBtn = document.getElementById("change-city-btn");
const bgFile = document.getElementById("bg-file");
const resetBgBtn = document.getElementById("reset-bg-btn");

let panelMsgTimer = null;
function showPanelMessage(text, isError = false) {
  panelMsg.textContent = text;
  panelMsg.classList.toggle("error", isError);
  clearTimeout(panelMsgTimer);
  panelMsgTimer = setTimeout(() => { panelMsg.textContent = ""; }, 4000);
}

// ---- Search engine -----------------------------------------------------------

function setIconSvg(container, svgMarkup) {
  const doc = new DOMParser().parseFromString(svgMarkup, "image/svg+xml");
  container.replaceChildren(document.importNode(doc.documentElement, true));
}

function setEngine(key) {
  const k = Object.prototype.hasOwnProperty.call(ENGINES, key) ? key : DEFAULT_ENGINE;
  const eng = ENGINES[k];
  localStorage.setItem("ntp_engine", k);
  setIconSvg(engineIcon, eng.icon);
  searchInput.placeholder = `Search with ${eng.name} or enter address`;
  engineSelect.value = k;
}

function currentEngine() {
  return ENGINES[engineSelect.value] || ENGINES[DEFAULT_ENGINE];
}

setEngine(localStorage.getItem("ntp_engine") || DEFAULT_ENGINE);

engineIcon.addEventListener("click", () => {
  const keys = Object.keys(ENGINES);
  const next = keys[(keys.indexOf(engineSelect.value) + 1) % keys.length];
  setEngine(next);
});

engineSelect.addEventListener("change", (e) => setEngine(e.target.value));

// Address bar style input: decide whether the text is an address or a search.
const HAS_WEB_SCHEME = /^https?:\/\//i;
const LOCAL_HOST = /^(localhost|\d{1,3}(\.\d{1,3}){3}|\[[0-9a-f:]+\])(:\d{1,5})?([/?#].*)?$/i;
const PUBLIC_HOST = /^([a-z\d]([a-z\d-]*[a-z\d])?\.)+[a-z]{2,}\.?(:\d{1,5})?([/?#].*)?$/i;

function toAddress(q) {
  if (/\s/.test(q)) return null;
  if (HAS_WEB_SCHEME.test(q)) return q;
  if (LOCAL_HOST.test(q)) return `http://${q}`;
  if (PUBLIC_HOST.test(q)) return `https://${q}`;
  return null;
}

searchForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const q = searchInput.value.trim();
  if (!q) return;
  const target = toAddress(q) || `${currentEngine().url}${encodeURIComponent(q)}`;
  window.top.location.href = target;
});

pencilBtn.addEventListener("click", () => panel.classList.toggle("hidden"));

// ---- Background image (stored in IndexedDB, not localStorage) -----------------
// localStorage caps out around 5 MB, so photos used to fail silently.
// IndexedDB has no practical limit here, and very large images are scaled down
// so every new tab doesn't have to decode a 40-megapixel photo.

const BG_KEY = "background";
const BG_MAX_EDGE = 3840;
const BG_KEEP_ORIGINAL_UNDER = 2 * 1024 * 1024;

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("hello-ntp", 1);
    req.onupgradeneeded = () => req.result.createObjectStore("kv");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function dbRun(mode, fn) {
  const db = await openDb();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction("kv", mode);
      const req = fn(tx.objectStore("kv"));
      tx.oncomplete = () => resolve(req.result);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}

const dbGet = (key) => dbRun("readonly", (s) => s.get(key));
const dbSet = (key, val) => dbRun("readwrite", (s) => s.put(val, key));
const dbDelete = (key) => dbRun("readwrite", (s) => s.delete(key));

async function prepareBackground(file) {
  let bitmap = null;
  try {
    bitmap = await createImageBitmap(file);
  } catch (e) {
    // Formats Chrome can show but not decode here (e.g. some SVGs): keep as is.
    if (file.size <= BG_KEEP_ORIGINAL_UNDER) return file;
    const err = new Error("undecodable image");
    err.userMessage = "Couldn't read that image. Try a JPG, PNG or WebP file.";
    throw err;
  }
  try {
    const longEdge = Math.max(bitmap.width, bitmap.height);
    // Small enough already: keep the original (this also keeps GIFs animated).
    if (file.size <= BG_KEEP_ORIGINAL_UNDER && longEdge <= BG_MAX_EDGE) return file;
    const scale = Math.min(1, BG_MAX_EDGE / longEdge);
    const w = Math.round(bitmap.width * scale);
    const h = Math.round(bitmap.height * scale);
    const canvas = new OffscreenCanvas(w, h);
    canvas.getContext("2d").drawImage(bitmap, 0, 0, w, h);
    return await canvas.convertToBlob({ type: "image/webp", quality: 0.9 });
  } finally {
    bitmap.close();
  }
}

let bgObjectUrl = null;

function showBackground(blob) {
  if (bgObjectUrl) URL.revokeObjectURL(bgObjectUrl);
  bgObjectUrl = blob ? URL.createObjectURL(blob) : null;
  document.body.style.backgroundImage = bgObjectUrl ? `url("${bgObjectUrl}")` : "";
  document.body.classList.toggle("has-custom-bg", !!bgObjectUrl);
}

async function applySavedBg() {
  try {
    // Move a background saved by an older version out of localStorage.
    const legacy = localStorage.getItem("ntp_bg");
    if (legacy) {
      const blob = await (await fetch(legacy)).blob();
      await dbSet(BG_KEY, blob);
      localStorage.removeItem("ntp_bg");
    }
    showBackground((await dbGet(BG_KEY)) || null);
  } catch (e) {
    showBackground(null);
  }
}
applySavedBg();

bgFile.addEventListener("change", async (e) => {
  const file = e.target.files[0];
  e.target.value = ""; // allow choosing the same file again later
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    showPanelMessage("That file isn't an image.", true);
    return;
  }
  showPanelMessage("Saving background…");
  try {
    const blob = await prepareBackground(file);
    await dbSet(BG_KEY, blob);
    showBackground(blob);
    showPanelMessage("Background saved.");
  } catch (err) {
    showPanelMessage((err && err.userMessage) || "Couldn't save that image. Try a smaller one.", true);
  }
});

resetBgBtn.addEventListener("click", async () => {
  try {
    await dbDelete(BG_KEY);
  } catch (e) {}
  localStorage.removeItem("ntp_bg");
  showBackground(null);
  showPanelMessage("Default background restored.");
});

// ---- Weather -------------------------------------------------------------------

const showWeather = localStorage.getItem("ntp_show_weather") !== "false";
toggleWeather.checked = showWeather;
weatherCard.style.display = showWeather ? "block" : "none";

toggleWeather.addEventListener("change", (e) => {
  localStorage.setItem("ntp_show_weather", e.target.checked);
  weatherCard.style.display = e.target.checked ? "block" : "none";
  if (e.target.checked && !weatherStarted) initWeather();
});

// WMO weather codes, as used by Open-Meteo.
function weatherEmoji(code) {
  if (code === 0) return "☀️";                  // clear
  if (code === 1 || code === 2) return "⛅";     // mainly clear, partly cloudy
  if (code === 3) return "☁️";                  // overcast
  if (code === 45 || code === 48) return "🌫️";  // fog
  if (code >= 51 && code <= 57) return "🌦️";    // drizzle
  if (code >= 61 && code <= 67) return "🌧️";    // rain, freezing rain
  if (code >= 71 && code <= 77) return "❄️";    // snow, snow grains
  if (code >= 80 && code <= 82) return "🌧️";    // rain showers
  if (code === 85 || code === 86) return "🌨️";  // snow showers
  if (code >= 95 && code <= 99) return "⛈️";    // thunderstorm
  return "🌡️";
}

const wCity = document.getElementById("w-city");
const wNow = document.getElementById("w-now");
const wRange = document.getElementById("w-range");
const wIcon = document.getElementById("w-icon");

const FETCH_TIMEOUT_MS = 5000;
const IP_LOCATION_TTL_MS = 6 * 60 * 60 * 1000;   // re-detect location every 6 h
const IP_FAILURE_TTL_MS = 30 * 60 * 1000;        // after a total failure, wait 30 min
const WEATHER_TTL_MS = 10 * 60 * 1000;           // reuse weather for 10 min

function readJson(key) {
  try {
    return JSON.parse(localStorage.getItem(key) || "null");
  } catch (e) {
    return null;
  }
}

async function getJson(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(FETCH_TIMEOUT_MS), cache: "no-store" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function validCoords(lat, lon) {
  lat = Number(lat);
  lon = Number(lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  if (Math.abs(lat) > 90 || Math.abs(lon) > 180 || (lat === 0 && lon === 0)) return null;
  return { lat, lon };
}

function renderWeather(data, label) {
  wCity.textContent = label;
  wNow.textContent = `${Math.round(data.current.temperature_2m)}°F`;
  wRange.textContent = `↑${Math.round(data.daily.temperature_2m_max[0])}°  ↓${Math.round(data.daily.temperature_2m_min[0])}°`;
  wIcon.textContent = weatherEmoji(data.current.weather_code);
}

function renderWeatherUnavailable(label, reason) {
  wCity.textContent = label;
  wNow.textContent = "--°F";
  wRange.textContent = "↑--°  ↓--°";
  wIcon.textContent = "🌡️";
  weatherCard.title = `${reason} Click to set a city.`;
}

async function fetchWeather(lat, lon, label) {
  wCity.textContent = label;
  weatherCard.title = "Click to change city";
  const cacheKey = `${lat.toFixed(3)},${lon.toFixed(3)}`;
  const cached = readJson("ntp_weather_cache");
  if (cached && cached.key === cacheKey && Date.now() - cached.ts < WEATHER_TTL_MS) {
    renderWeather(cached.data, label);
    return;
  }
  try {
    const data = await getJson(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&temperature_unit=fahrenheit&timezone=auto`);
    if (!data || !data.current || !data.daily) throw new Error("Bad weather response");
    localStorage.setItem("ntp_weather_cache", JSON.stringify({ key: cacheKey, ts: Date.now(), data }));
    renderWeather(data, label);
  } catch (err) {
    if (cached && cached.key === cacheKey) {
      renderWeather(cached.data, label); // stale beats nothing
    } else {
      renderWeatherUnavailable(label, "Weather is unavailable right now.");
    }
  }
}

// Location by IP: try each service in turn until one gives usable coordinates.
// All are HTTPS, keyless and allow requests from browser pages (CORS).
const IP_LOCATION_PROVIDERS = [
  {
    name: "ipapi.co",
    url: "https://ipapi.co/json/",
    parse: (d) => (d.error ? null : { ...validCoords(d.latitude, d.longitude), city: d.city })
  },
  {
    name: "ipwho.is",
    url: "https://ipwho.is/",
    parse: (d) => (d.success === false ? null : { ...validCoords(d.latitude, d.longitude), city: d.city })
  },
  {
    name: "freeipapi.com",
    url: "https://freeipapi.com/api/json",
    parse: (d) => ({ ...validCoords(d.latitude, d.longitude), city: d.cityName })
  },
  {
    name: "geojs.io",
    url: "https://get.geojs.io/v1/ip/geo.json",
    parse: (d) => ({ ...validCoords(d.latitude, d.longitude), city: d.city })
  },
  {
    name: "ipinfo.io",
    url: "https://ipinfo.io/json",
    parse: (d) => {
      const [lat, lon] = String(d.loc || "").split(",");
      return { ...validCoords(lat, lon), city: d.city };
    }
  },
  {
    name: "reallyfreegeoip.org",
    url: "https://reallyfreegeoip.org/json/",
    parse: (d) => ({ ...validCoords(d.latitude, d.longitude), city: d.city })
  }
];

async function locateByIp() {
  for (const provider of IP_LOCATION_PROVIDERS) {
    try {
      const loc = provider.parse(await getJson(provider.url));
      if (loc && Number.isFinite(loc.lat) && Number.isFinite(loc.lon)) {
        return { lat: loc.lat, lon: loc.lon, name: (loc.city || "").trim() || "Local", source: provider.name };
      }
    } catch (err) {
      // rate-limited, blocked, offline or malformed: move on to the next one
    }
  }
  return null;
}

// Last resort when every IP service fails: ask the browser (Chrome may prompt once).
function locateByBrowser() {
  return new Promise((resolve) => {
    if (!navigator.geolocation) return resolve(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const c = validCoords(pos.coords.latitude, pos.coords.longitude);
        resolve(c ? { ...c, name: "Your location", source: "browser" } : null);
      },
      () => resolve(null),
      { timeout: 8000, maximumAge: IP_LOCATION_TTL_MS }
    );
  });
}

let weatherStarted = false;

async function initWeather() {
  if (!toggleWeather.checked) return; // don't make network calls for a hidden card
  weatherStarted = true;

  const saved = readJson("ntp_city");
  if (saved && validCoords(saved.lat, saved.lon)) {
    changeCityBtn.textContent = saved.name;
    fetchWeather(Number(saved.lat), Number(saved.lon), saved.name);
    return;
  }

  const cachedLoc = readJson("ntp_auto_location");
  if (cachedLoc && Date.now() - cachedLoc.ts < IP_LOCATION_TTL_MS && validCoords(cachedLoc.lat, cachedLoc.lon)) {
    fetchWeather(cachedLoc.lat, cachedLoc.lon, cachedLoc.name);
    return;
  }

  const lastFail = Number(localStorage.getItem("ntp_auto_location_failed") || 0);
  if (Date.now() - lastFail < IP_FAILURE_TTL_MS) {
    renderWeatherUnavailable("Set City", "Couldn't detect your location.");
    return;
  }

  const loc = (await locateByIp()) || (await locateByBrowser());
  if (loc) {
    localStorage.removeItem("ntp_auto_location_failed");
    localStorage.setItem("ntp_auto_location", JSON.stringify({ ...loc, ts: Date.now() }));
    fetchWeather(loc.lat, loc.lon, loc.name);
  } else {
    localStorage.setItem("ntp_auto_location_failed", String(Date.now()));
    renderWeatherUnavailable("Set City", "Couldn't detect your location.");
  }
}

async function setCityByName(name) {
  const previous = wCity.textContent;
  wCity.textContent = "Searching…";
  try {
    const gData = await getJson(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=1`);
    const place = gData && gData.results && gData.results[0];
    const coords = place && validCoords(place.latitude, place.longitude);
    if (!coords) {
      wCity.textContent = previous;
      alert(`Couldn't find a city called "${name}". Try just the city name, e.g. "London".`);
      return;
    }
    localStorage.setItem("ntp_city", JSON.stringify({ lat: coords.lat, lon: coords.lon, name: place.name }));
    changeCityBtn.textContent = place.name;
    weatherStarted = true;
    fetchWeather(coords.lat, coords.lon, place.name);
  } catch (err) {
    wCity.textContent = previous;
    alert("Couldn't look up that city right now. Check your connection and try again.");
  }
}

function promptCity() {
  const city = prompt("Enter city name (e.g., Cincinnati or London). Leave empty to detect automatically:", "");
  if (city === null) return;
  if (city.trim()) {
    setCityByName(city.trim());
  } else {
    localStorage.removeItem("ntp_city");
    localStorage.removeItem("ntp_auto_location");
    localStorage.removeItem("ntp_auto_location_failed");
    changeCityBtn.textContent = "Auto";
    wCity.textContent = "Detecting...";
    initWeather();
  }
}

weatherCard.addEventListener("click", promptCity);
changeCityBtn.addEventListener("click", promptCity);
initWeather();
