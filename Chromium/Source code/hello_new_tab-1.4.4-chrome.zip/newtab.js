const frame = document.getElementById("ntp-frame");
const overlay = document.getElementById("setup-overlay");
const btnDefault = document.getElementById("btn-default");
const btnCustomChoice = document.getElementById("btn-custom-choice");
const customWrap = document.getElementById("custom-input-wrap");
const customInput = document.getElementById("custom-url-input");
const btnSaveCustom = document.getElementById("btn-save-custom");
const overlayMsg = document.getElementById("overlay-msg");

const DEFAULT_PAGE = chrome.runtime.getURL("default-ntp.html");
const ALL_URLS = { origins: ["<all_urls>"] };

function normalizeUrl(raw) {
  let val = (raw || "").trim();
  if (!val) return "";
  if (!/^[a-z][a-z\d+.-]*:\/\//i.test(val)) {
    const local = /^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?([/?#]|$)/i.test(val);
    val = (local ? "http://" : "https://") + val;
  }
  return val;
}

// ---- Header stripping, scoped to this tab only ------------------------------
// Instead of removing X-Frame-Options / CSP from every frame on every site,
// we add a session rule that only applies to sub-frames in *this* new-tab tab,
// and only to frames started by this extension page or by the chosen site.
// background.js removes the rule as soon as the tab navigates away or closes.

let currentTabId = null;
let framingUrl = null;

async function getTabId() {
  if (currentTabId === null) {
    const tab = await chrome.tabs.getCurrent();
    currentTabId = tab ? tab.id : -1;
  }
  return currentTabId;
}

function siteDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./i, "") || null;
  } catch (e) {
    return null;
  }
}

async function enableFraming(url) {
  framingUrl = url;
  const tabId = await getTabId();
  if (tabId < 0) return;
  const initiatorDomains = [chrome.runtime.id];
  const d = siteDomain(url);
  if (d) initiatorDomains.push(d);
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [tabId],
    addRules: [{
      id: tabId,
      priority: 1,
      action: {
        type: "modifyHeaders",
        responseHeaders: [
          { header: "x-frame-options", operation: "remove" },
          { header: "content-security-policy", operation: "remove" }
        ]
      },
      condition: {
        tabIds: [tabId],
        initiatorDomains,
        resourceTypes: ["sub_frame"]
      }
    }]
  });
}

async function disableFraming() {
  framingUrl = null;
  const tabId = await getTabId();
  if (tabId < 0) return;
  try {
    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [tabId] });
  } catch (e) {}
}

// ---- Overlay ---------------------------------------------------------------

function showOverlay({ customUrl = "", message = "" } = {}) {
  overlay.classList.remove("hidden");
  if (customUrl || message) {
    customWrap.classList.remove("hidden");
    customInput.value = customUrl;
  }
  overlayMsg.textContent = message;
  overlayMsg.classList.toggle("hidden", !message);
}

function hideOverlay() {
  overlay.classList.add("hidden");
  overlayMsg.classList.add("hidden");
}

// ---- Apply settings ----------------------------------------------------------

let applySeq = 0;
let loadedSrc = null;

function setFrame(src) {
  if (loadedSrc !== src) {
    loadedSrc = src;
    frame.src = src;
  }
}

async function applyChoice(mode, customUrl) {
  const seq = ++applySeq;
  if (mode === "custom" && customUrl) {
    const url = normalizeUrl(customUrl);
    const granted = await chrome.permissions.contains(ALL_URLS);
    if (seq !== applySeq) return;
    if (!granted) {
      await disableFraming();
      setFrame("about:blank");
      showOverlay({
        customUrl: url,
        message: "Chrome needs website access to show your custom page. Click the button to allow it."
      });
      return;
    }
    await enableFraming(url);
    if (seq !== applySeq) return;
    setFrame(url);
  } else {
    await disableFraming();
    if (seq !== applySeq) return;
    setFrame(DEFAULT_PAGE);
  }
  hideOverlay();
}

async function loadAndApply() {
  const res = await chrome.storage.local.get(["ntpMode", "ntpCustomUrl"]);
  if (!res.ntpMode) {
    showOverlay();
  } else {
    await applyChoice(res.ntpMode, res.ntpCustomUrl);
  }
}

loadAndApply();

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.ntpMode || changes.ntpCustomUrl)) loadAndApply();
});

chrome.permissions.onAdded.addListener(loadAndApply);
chrome.permissions.onRemoved.addListener(loadAndApply);

// Restored from the back/forward cache: background.js removed the rule when
// the tab navigated away, so put it back.
window.addEventListener("pageshow", (e) => {
  if (e.persisted && framingUrl) enableFraming(framingUrl);
});

window.addEventListener("pagehide", () => {
  try { chrome.runtime.sendMessage({ type: "ntp-leaving" }); } catch (e) {}
});

btnDefault.addEventListener("click", async () => {
  await chrome.storage.local.set({ ntpMode: "default" });
  applyChoice("default", "");
});

btnCustomChoice.addEventListener("click", () => {
  customWrap.classList.remove("hidden");
  customInput.focus();
});

async function saveCustomFromOverlay() {
  const url = normalizeUrl(customInput.value);
  if (!url) return;
  let granted = false;
  try {
    granted = await chrome.permissions.request(ALL_URLS);
  } catch (e) {}
  if (!granted) {
    showOverlay({
      customUrl: url,
      message: "Website access wasn't allowed, so the custom page can't be shown. Try again, or pick the default page."
    });
    return;
  }
  await chrome.storage.local.set({ ntpMode: "custom", ntpCustomUrl: url });
  applyChoice("custom", url);
}

btnSaveCustom.addEventListener("click", saveCustomFromOverlay);
customInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveCustomFromOverlay();
});
