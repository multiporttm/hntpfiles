const radioDefault = document.getElementById("radio-default");
const radioCustom = document.getElementById("radio-custom");
const cardDefault = document.getElementById("card-default");
const cardCustom = document.getElementById("card-custom");
const urlBox = document.getElementById("url-box");
const urlInput = document.getElementById("url-input");
const permBanner = document.getElementById("perm-banner");
const grantPermBtn = document.getElementById("grant-perm-btn");
const saveBtn = document.getElementById("save-btn");
const statusMsg = document.getElementById("status-msg");

function normalizeUrl(raw) {
  let val = (raw || "").trim();
  if (!val) return "";
  if (!/^[a-z][a-z\d+.-]*:\/\//i.test(val)) {
    const local = /^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?([/?#]|$)/i.test(val);
    val = (local ? "http://" : "https://") + val;
  }
  return val;
}

async function checkHostPermission() {
  if (!radioCustom.checked) {
    permBanner.classList.add("hidden");
    return;
  }
  const hasPerm = await chrome.permissions.contains({ origins: ["<all_urls>"] });
  if (hasPerm) {
    permBanner.classList.add("hidden");
  } else {
    permBanner.classList.remove("hidden");
  }
}

function updateUI() {
  if (radioCustom.checked) {
    cardCustom.classList.add("active");
    cardDefault.classList.remove("active");
    urlBox.classList.remove("hidden");
  } else {
    cardDefault.classList.add("active");
    cardCustom.classList.remove("active");
    urlBox.classList.add("hidden");
  }
  checkHostPermission();
}

chrome.storage.local.get(["ntpMode", "ntpCustomUrl"]).then((res) => {
  const mode = res.ntpMode || "default";
  if (mode === "custom") {
    radioCustom.checked = true;
  } else {
    radioDefault.checked = true;
  }
  urlInput.value = res.ntpCustomUrl || "";
  updateUI();
});

radioDefault.addEventListener("change", updateUI);
radioCustom.addEventListener("change", () => {
  updateUI();
  urlInput.focus();
});

grantPermBtn.addEventListener("click", async () => {
  const granted = await chrome.permissions.request({ origins: ["<all_urls>"] });
  if (granted) {
    permBanner.classList.add("hidden");
    statusMsg.textContent = "Permission granted!";
    setTimeout(() => { statusMsg.textContent = ""; }, 2000);
  }
});

async function saveSettings() {
  const mode = radioCustom.checked ? "custom" : "default";
  let customUrl = normalizeUrl(urlInput.value);

  if (mode === "custom" && !customUrl) {
    statusMsg.style.color = "#ff848b";
    statusMsg.textContent = "Please enter a valid URL.";
    return;
  }

  // Start the permission request first, while the click still counts as a user
  // gesture, then save straight away. On some systems Chrome closes the popup
  // when its permission prompt opens, so saving must not wait for the answer.
  // If access is denied, the new tab page asks for it again.
  const permRequest = mode === "custom"
    ? chrome.permissions.request({ origins: ["<all_urls>"] }).catch(() => false)
    : null;

  await chrome.storage.local.set({ ntpMode: mode, ntpCustomUrl: customUrl });

  if (permRequest) {
    const granted = await permRequest;
    await checkHostPermission();
    if (!granted) {
      statusMsg.style.color = "#ff848b";
      statusMsg.textContent = "Saved, but website access is needed to show it.";
      return;
    }
  }

  statusMsg.style.color = "#54ffbd";
  statusMsg.textContent = "Saved! New tab updated.";
  setTimeout(() => { statusMsg.textContent = ""; }, 2000);
}

saveBtn.addEventListener("click", saveSettings);
urlInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveSettings();
});
